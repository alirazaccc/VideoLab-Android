# VideoLab Android (MVP)

A local-first Android video editing/test project for video you own or have permission to edit.

## Included now
- Android/Jetpack Compose project
- Video picker using Android's system picker (no broad storage permission)
- Brightness and contrast configuration
- Mirror option
- Smart-cut and preserve-dialogue configuration switches
- Full-timeline overlay configuration
- Non-destructive design: original input is not overwritten
- GitHub Actions workflow that builds a debug APK

## Important implementation status
The UI/configuration layer is implemented. The actual render pipeline is deliberately not faked: the current **Prepare edit** button stores/validates the editing choices but does not yet render a transformed video. Media3 dependencies are included so the next iteration can wire the renderer after testing codec/effect support on the target Android phone.

“Smart cuts” also requires real scene/silence/dialogue analysis; it should not be implemented as random cuts because that can remove important speech.

## Build APK on GitHub (no PC Android Studio needed)
1. Create a new GitHub repository.
2. Upload all files from this project, preserving folders.
3. Commit to `main`.
4. Open **Actions → Build APK → Run workflow**.
5. When it finishes, open the run and download the `VideoLab-debug-apk` artifact.
6. Extract it to get `app-debug.apk` and install it on your Android phone.

## Build on PC
Use JDK 17. Open the project in Android Studio and build a Debug APK, or run `gradle assembleDebug` if Gradle is installed.

## Intended next milestone
- Media3 local export renderer
- Device capability check before rendering
- Preview player
- Overlay image/logo picker
- Reframe presets (9:16, 1:1, 16:9)
- Scene-boundary analysis and speech-safe cut suggestions
- Export queue and progress

This project is for legitimate editing/testing of owned or authorized content, not bypassing third-party copyright detection.
