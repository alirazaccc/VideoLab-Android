package com.aliraza.videolab

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VideoLabScreen() } }
    }
}

@Composable
private fun VideoLabScreen() {
    var input by remember { mutableStateOf<Uri?>(null) }
    var mirror by remember { mutableStateOf(false) }
    var smartCuts by remember { mutableStateOf(true) }
    var preserveDialogue by remember { mutableStateOf(true) }
    var overlay by remember { mutableStateOf(true) }
    var overlayText by remember { mutableStateOf("MY CONTENT") }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var status by remember { mutableStateOf("Ready") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        input = uri
        status = if (uri == null) "No video selected" else "Video selected"
    }

    Column(Modifier.fillMaxSize().padding(18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("VideoLab", style = MaterialTheme.typography.headlineMedium)
        Text("Local editor for videos you own or are authorized to edit. Original file is never overwritten.")
        Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) { Text("Select video") }
        Text(input?.lastPathSegment ?: "No video selected")

        Text("Visual adjustments", style = MaterialTheme.typography.titleMedium)
        Text("Brightness ${(brightness * 100).toInt()}%")
        Slider(brightness, { brightness = it }, valueRange = -0.5f..0.5f)
        Text("Contrast ${"%.2f".format(contrast)}×")
        Slider(contrast, { contrast = it }, valueRange = 0.5f..1.5f)
        SwitchRow("Mirror", mirror) { mirror = it }

        Text("Content-aware editing", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Smart cuts at safe boundaries", smartCuts) { smartCuts = it }
        SwitchRow("Preserve dialogue", preserveDialogue) { preserveDialogue = it }

        Text("Full-timeline overlay", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Enable overlay", overlay) { overlay = it }
        OutlinedTextField(overlayText, { overlayText = it.take(40) }, label = { Text("Overlay text") }, enabled = overlay, modifier = Modifier.fillMaxWidth())

        Button(onClick = {
            status = if (input == null) "Select a video first" else "Preset saved. Rendering engine wiring is the next build step."
        }, modifier = Modifier.fillMaxWidth()) { Text("Prepare edit") }
        Text(status)
        HorizontalDivider()
        Text("MVP note: this build contains the complete mobile UI/configuration layer. The renderer is intentionally separated so Media3/codec support can be validated on the target phone before destructive batch rendering is enabled.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, modifier = Modifier.weight(1f).padding(end = 12.dp))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
