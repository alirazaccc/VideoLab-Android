plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.aliraza.videolab"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aliraza.videolab"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.media3:media3-common:1.6.0")
    implementation("androidx.media3:media3-transformer:1.6.0")
    implementation("androidx.media3:media3-effect:1.6.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
